## It is an Online Shopping web application developed using Vuejs, Swiperjs, Pinia and JavaScript.

### Technology used in this Project:

- Vuejs
- Pinia
- Swiperjs
- Html
- Sass

### Some Screenshots of this Project:

# ![Category page](public/a2.png)

# ![Category page](public/a3.png)

# ![Mobile menu](public/a4.png)

- [Demo version](https://ecommerce-demo-project.vercel.app/)
