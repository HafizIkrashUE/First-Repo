<template>
  <div>
    <span>photo navigation</span>
  </div>
</template>
