<script setup>
import MainLayout from "./layouts/MainLayout.vue";
</script>

<template>
  <MainLayout>
    <router-view />
  </MainLayout>
</template>
