export default [
  {
    path: "/category/electronics",
    name: "Electronics",
  },
  {
    path: "/category/phones",
    name: "Phones",
  },
  {
    path: "/category/smart-watches",
    name: "Smart watches",
  },
  {
    path: "/category/computers",
    name: "Computers",
  },
];
